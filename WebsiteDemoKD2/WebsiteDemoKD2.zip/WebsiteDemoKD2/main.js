//Javascript

/**
 * In Javascript bestimmt ihr das Verhalten eurer Website auf Eingaben, die Zeit, Daten, ...
 * Hier könnt ihr auch mit externen Libraries wie p5js arbeiten.
 */